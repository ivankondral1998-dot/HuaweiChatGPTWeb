package app.uno.pulse;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Pure-Java launcher logic; can be tested without an Android SDK. */
public final class LauncherLogic {
    private LauncherLogic() {}

    public static List<String> decodeFavorites(String value) {
        Set<String> result = new LinkedHashSet<>();
        if (value != null && !value.isEmpty()) {
            for (String item : value.split("\\|", -1)) {
                if (!item.trim().isEmpty()) result.add(item);
            }
        }
        return new ArrayList<>(result);
    }

    public static String encodeFavorites(List<String> favorites) {
        return String.join("|", favorites);
    }

    public static boolean matches(String label, String packageName, String query) {
        if (query == null || query.trim().isEmpty()) return true;
        String q = query.trim().toLowerCase(Locale.ROOT);
        return label.toLowerCase(Locale.ROOT).contains(q)
                || packageName.toLowerCase(Locale.ROOT).contains(q);
    }

    /** Toggles an app; returns null if favorites are full. */
    public static List<String> toggleFavorite(List<String> current, String id, int limit) {
        List<String> result = new ArrayList<>(current);
        if (result.remove(id)) return result;
        if (result.size() >= limit) return null;
        result.add(id);
        return result;
    }
}
