package app.uno.pulse;

import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Minimal-permission replacement HOME app. No networking, ads, trackers, root or services. */
public final class MainActivity extends Activity {
    private static final int BG = 0xFF07101B;
    private static final int CARD = 0xD3152233;
    private static final int FG = 0xFFF2F8FF;
    private static final int MUTED = 0xFF99AEC2;
    private static final int ACCENT = 0xFF6DFBE9;
    private static final int MAX_FAVORITES = 5;
    private static final String KEY_FAVORITES = "favorites";
    private static final Locale RU = new Locale("ru", "RU");

    private final List<AppEntry> apps = new ArrayList<>();
    private List<String> favorites = new ArrayList<>();
    private SharedPreferences preferences;
    private FrameLayout root;
    private LinearLayout drawer;
    private GridLayout grid;
    private LinearLayout favoritesRow;
    private TextView batteryLabel;
    private EditText searchInput;
    private OrbitView orbit;
    private boolean drawerVisible;

    private static final class AppEntry {
        final String key, label, packageName, className;
        final Drawable icon;
        AppEntry(ResolveInfo info, PackageManager pm) {
            packageName = info.activityInfo.packageName;
            className = info.activityInfo.name;
            key = new ComponentName(packageName, className).flattenToString();
            CharSequence appLabel = info.loadLabel(pm);
            label = appLabel == null ? packageName : appLabel.toString();
            icon = info.loadIcon(pm);
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        preferences = getSharedPreferences("pulse", MODE_PRIVATE);
        favorites = LauncherLogic.decodeFavorites(preferences.getString(KEY_FAVORITES, ""));
        loadApps();
        buildInterface();
    }

    @Override protected void onResume() {
        super.onResume();
        if (root == null) return;
        loadApps();
        populateFavorites();
        if (drawerVisible) populateDrawer();
        updateBattery();
        orbit.setRunning(!drawerVisible);
    }

    @Override protected void onPause() {
        if (orbit != null) orbit.setRunning(false);
        super.onPause();
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> matches = pm.queryIntentActivities(intent, 0);
        apps.clear();
        Set<String> seen = new HashSet<>();
        for (ResolveInfo info : matches) {
            if (info.activityInfo == null || !info.activityInfo.enabled) continue;
            try {
                AppEntry entry = new AppEntry(info, pm);
                if (seen.add(entry.key)) apps.add(entry);
            } catch (RuntimeException ignored) {
                // A package may be uninstalled or disabled during a refresh.
            }
        }
        final Collator collator = Collator.getInstance(RU);
        apps.sort((a, b) -> collator.compare(a.label, b.label));
        if (!preferences.contains(KEY_FAVORITES)) {
            // Prioritize familiar tools, but never require a specific vendor package.
            String[] preferred = {"camera", "dialer", "contacts", "messaging", "chrome"};
            for (String token : preferred) {
                for (AppEntry app : apps) {
                    String key = app.packageName.toLowerCase(Locale.ROOT);
                    if (key.contains(token) && !favorites.contains(app.key) && favorites.size() < MAX_FAVORITES) {
                        favorites.add(app.key);
                        break;
                    }
                }
            }
            for (AppEntry app : apps) {
                if (favorites.size() >= MAX_FAVORITES) break;
                if (!favorites.contains(app.key) && !app.packageName.equals(getPackageName())) favorites.add(app.key);
            }
            saveFavorites();
        }
    }

    private void buildInterface() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(22), dp(18), dp(22), dp(18));
        root.addView(home, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView branding = text("◈  UNO / PULSE", 13, ACCENT, true);
        branding.setLetterSpacing(.13f);
        top.addView(branding, new LinearLayout.LayoutParams(0, dp(44), 1));
        branding.setGravity(Gravity.CENTER_VERTICAL);
        batteryLabel = text("…", 12, MUTED, false);
        top.addView(batteryLabel);
        home.addView(top);

        TextView hello = text("ТВОЁ ПРОСТРАНСТВО", 10, MUTED, true);
        hello.setLetterSpacing(.18f);
        LinearLayout.LayoutParams helloLp = new LinearLayout.LayoutParams(-1, -2);
        helloLp.topMargin = dp(25);
        home.addView(hello, helloLp);

        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm");
        clock.setFormat24Hour("HH:mm");
        clock.setTextColor(FG);
        clock.setTextSize(67);
        clock.setIncludeFontPadding(false);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        home.addView(clock);

        TextView date = text(capitalize(new SimpleDateFormat("EEEE, d MMMM", RU).format(new java.util.Date())), 15, MUTED, false);
        home.addView(date);

        orbit = new OrbitView(this);
        orbit.setOnClickListener(v -> orbit.cyclePalette());
        final float[] touchStartY = new float[1];
        orbit.setOnTouchListener((v, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                touchStartY[0] = event.getY();
                return true;
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) {
                if (touchStartY[0] - event.getY() > dp(55)) openDrawer();
                else v.performClick();
                return true;
            }
            return event.getActionMasked() == MotionEvent.ACTION_MOVE;
        });
        LinearLayout.LayoutParams orbLp = new LinearLayout.LayoutParams(-1, 0, 1);
        orbLp.topMargin = dp(4);
        orbLp.bottomMargin = dp(2);
        home.addView(orbit, orbLp);

        LinearLayout favoritesTitle = new LinearLayout(this);
        favoritesTitle.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("ИЗБРАННОЕ", 11, ACCENT, true);
        title.setLetterSpacing(.14f);
        favoritesTitle.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView editHint = text("удерживай значок", 10, MUTED, false);
        favoritesTitle.addView(editHint);
        home.addView(favoritesTitle);

        favoritesRow = new LinearLayout(this);
        favoritesRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams favLp = new LinearLayout.LayoutParams(-1, dp(92));
        favLp.topMargin = dp(10);
        home.addView(favoritesRow, favLp);
        populateFavorites();

        LinearLayout actionRow = new LinearLayout(this);
        LinearLayout.LayoutParams actionsLp = new LinearLayout.LayoutParams(-1, dp(58));
        actionsLp.topMargin = dp(8);
        home.addView(actionRow, actionsLp);
        TextView drawerButton = actionButton("⌃   ВСЕ ПРИЛОЖЕНИЯ", true);
        actionRow.addView(drawerButton, new LinearLayout.LayoutParams(0, -1, 2.2f));
        drawerButton.setOnClickListener(v -> openDrawer());
        TextView settingsButton = actionButton("⚙", false);
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(0, -1, .65f);
        settingsLp.leftMargin = dp(10);
        actionRow.addView(settingsButton, settingsLp);
        settingsButton.setContentDescription("Открыть системные настройки");
        settingsButton.setOnClickListener(v -> safeStart(new Intent(Settings.ACTION_SETTINGS)));

        TextView footer = text("БЕЗ СЕТЕВЫХ РАЗРЕШЕНИЙ   •   БЕЗ РЕКЛАМЫ", 9, 0xFF708BA0, false);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(.06f);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, dp(28));
        footLp.topMargin = dp(7);
        home.addView(footer, footLp);

        createDrawer();
    }

    private void createDrawer() {
        drawer = new LinearLayout(this);
        drawer.setOrientation(LinearLayout.VERTICAL);
        drawer.setPadding(dp(16), dp(24), dp(16), dp(12));
        drawer.setBackgroundColor(0xFF0A1220);
        drawer.setVisibility(View.GONE);
        root.addView(drawer, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView drawerTitle = text("ПРИЛОЖЕНИЯ", 21, FG, true);
        header.addView(drawerTitle, new LinearLayout.LayoutParams(0, dp(55), 1));
        drawerTitle.setGravity(Gravity.CENTER_VERTICAL);
        TextView homeRole = actionButton("⌂", false);
        homeRole.setTextSize(23);
        homeRole.setContentDescription("Сделать UNO Pulse домашним экраном по умолчанию");
        header.addView(homeRole, new LinearLayout.LayoutParams(dp(46), dp(46)));
        homeRole.setOnClickListener(v -> requestHomeRole());
        TextView close = actionButton("×", false);
        close.setTextSize(26);
        LinearLayout.LayoutParams closeLp = new LinearLayout.LayoutParams(dp(46), dp(46));
        closeLp.leftMargin = dp(8);
        header.addView(close, closeLp);
        close.setContentDescription("Закрыть список приложений");
        close.setOnClickListener(v -> closeDrawer());
        drawer.addView(header);

        searchInput = new EditText(this);
        searchInput.setTextSize(16);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(FG);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Поиск приложения…");
        searchInput.setCompoundDrawablePadding(dp(8));
        searchInput.setPadding(dp(18), 0, dp(18), 0);
        searchInput.setBackground(roundCard(0xFF18273A, 0xFF334E60, 18));
        searchInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(54));
        searchLp.topMargin = dp(12);
        searchLp.bottomMargin = dp(10);
        drawer.addView(searchInput, searchLp);

        TextView hint = text("НАЖАТИЕ — ЗАПУСТИТЬ    •    УДЕРЖАНИЕ — В ИЗБРАННОЕ", 9, MUTED, false);
        hint.setGravity(Gravity.CENTER_VERTICAL);
        hint.setLetterSpacing(.02f);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, dp(30));
        drawer.addView(hint, hintLp);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        grid = new GridLayout(this);
        grid.setColumnCount(4);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        scroll.addView(grid, new ScrollView.LayoutParams(-1, -2));
        drawer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { populateDrawer(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        populateDrawer();
    }

    private void populateFavorites() {
        if (favoritesRow == null) return;
        favoritesRow.removeAllViews();
        List<AppEntry> items = new ArrayList<>();
        for (String key : favorites) {
            for (AppEntry entry : apps) if (entry.key.equals(key)) { items.add(entry); break; }
        }
        for (AppEntry entry : items) {
            View tile = appTile(entry, true);
            favoritesRow.addView(tile, new LinearLayout.LayoutParams(0, dp(88), 1));
        }
        if (items.size() < MAX_FAVORITES) {
            TextView add = text("+", 28, ACCENT, false);
            add.setGravity(Gravity.CENTER);
            add.setBackground(roundCard(CARD, 0x3356BAAB, 16));
            LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(0, dp(68), 1);
            addLp.setMargins(dp(3), 0, dp(3), 0);
            favoritesRow.addView(add, addLp);
            add.setContentDescription("Добавить избранное приложение");
            add.setOnClickListener(v -> openDrawer());
        }
    }

    private void populateDrawer() {
        if (grid == null || searchInput == null) return;
        grid.removeAllViews();
        String query = searchInput.getText().toString();
        int availableWidth = getResources().getDisplayMetrics().widthPixels - dp(32);
        int itemWidth = availableWidth / 4;
        for (AppEntry entry : apps) {
            if (!LauncherLogic.matches(entry.label, entry.packageName, query)) continue;
            View tile = appTile(entry, false);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = itemWidth;
            lp.height = dp(104);
            grid.addView(tile, lp);
        }
        if (grid.getChildCount() == 0) {
            TextView none = text("Ничего не найдено", 14, MUTED, false);
            none.setGravity(Gravity.CENTER);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = availableWidth;
            lp.height = dp(100);
            grid.addView(none, lp);
        }
    }

    private View appTile(AppEntry entry, boolean compact) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(3), dp(5), dp(3), dp(3));
        tile.setBackground(roundCard(compact ? 0xA419293B : 0x0019293B,
                compact ? 0x224DD7C8 : 0x0019293B, 14));
        ImageView icon = new ImageView(this);
        icon.setImageDrawable(entry.icon);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tile.addView(icon, new LinearLayout.LayoutParams(dp(compact ? 43 : 49), dp(compact ? 43 : 49)));
        TextView label = text(entry.label, compact ? 10 : 11, FG, false);
        label.setGravity(Gravity.CENTER);
        label.setMaxLines(2);
        label.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(-1, -2);
        labelLp.topMargin = dp(5);
        tile.addView(label, labelLp);
        if (!compact && favorites.contains(entry.key)) {
            label.setTextColor(ACCENT);
        }
        tile.setContentDescription(entry.label + (favorites.contains(entry.key) ? ", в избранном" : ""));
        tile.setOnClickListener(v -> launchApp(entry));
        tile.setOnLongClickListener(v -> { toggleFavorite(entry); return true; });
        return tile;
    }

    private void toggleFavorite(AppEntry entry) {
        List<String> changed = LauncherLogic.toggleFavorite(favorites, entry.key, MAX_FAVORITES);
        if (changed == null) {
            toast("В избранном максимум " + MAX_FAVORITES + " приложений");
            return;
        }
        boolean added = changed.contains(entry.key);
        favorites = changed;
        saveFavorites();
        populateFavorites();
        if (drawerVisible) populateDrawer();
        toast(added ? "Добавлено в избранное" : "Удалено из избранного");
    }

    private void saveFavorites() {
        preferences.edit().putString(KEY_FAVORITES, LauncherLogic.encodeFavorites(favorites)).apply();
    }

    private void launchApp(AppEntry entry) {
        try {
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setComponent(new ComponentName(entry.packageName, entry.className));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(launch);
        } catch (RuntimeException ex) {
            toast("Не удалось открыть: " + entry.label);
            loadApps();
            populateDrawer();
        }
    }

    private void requestHomeRole() {
        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager roles = (RoleManager) getSystemService(Context.ROLE_SERVICE);
            if (roles != null && roles.isRoleAvailable(RoleManager.ROLE_HOME)) {
                if (roles.isRoleHeld(RoleManager.ROLE_HOME)) {
                    toast("UNO Pulse уже выбран домашним экраном");
                    return;
                }
                safeStart(roles.createRequestRoleIntent(RoleManager.ROLE_HOME));
                return;
            }
        }
        safeStart(new Intent(Settings.ACTION_HOME_SETTINGS));
    }

    private void safeStart(Intent intent) {
        try { startActivity(intent); }
        catch (ActivityNotFoundException | SecurityException e) { toast("Действие недоступно на этом устройстве"); }
    }

    private void openDrawer() {
        if (drawerVisible) return;
        drawerVisible = true;
        orbit.setRunning(false);
        searchInput.setText("");
        searchInput.clearFocus();
        drawer.setTranslationY(dp(80));
        drawer.setAlpha(0);
        drawer.setVisibility(View.VISIBLE);
        drawer.animate().translationY(0).alpha(1).setDuration(190).start();
    }

    private void closeDrawer() {
        if (!drawerVisible) return;
        drawerVisible = false;
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
        drawer.animate().translationY(dp(48)).alpha(0).setDuration(160)
                .withEndAction(() -> { if (!drawerVisible) drawer.setVisibility(View.GONE); }).start();
        orbit.setRunning(true);
    }

    @Override public void onBackPressed() {
        if (drawerVisible) closeDrawer();
        // A home screen stays in place when Back is pressed.
    }

    private void updateBattery() {
        if (batteryLabel == null) return;
        Intent state = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (state == null) { batteryLabel.setText("ЛОКАЛЬНО"); return; }
        int level = state.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = state.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        if (level < 0 || scale <= 0) batteryLabel.setText("ЛОКАЛЬНО");
        else batteryLabel.setText("▰  " + Math.round(level * 100f / scale) + "%");
    }

    private TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(sizeSp);
        tv.setTextColor(color);
        tv.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return tv;
    }

    private TextView actionButton(String label, boolean primary) {
        TextView tv = text(label, 13, primary ? BG : ACCENT, true);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(roundCard(primary ? ACCENT : CARD, primary ? ACCENT : 0x553A716F, 17));
        tv.setClickable(true);
        tv.setFocusable(true);
        return tv;
    }

    private GradientDrawable roundCard(int fill, int border, int radiusDp) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(fill);
        shape.setCornerRadius(dp(radiusDp));
        if ((border >>> 24) != 0) shape.setStroke(dp(1), border);
        return shape;
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }
    private static String capitalize(String value) {
        if (value == null || value.isEmpty()) return "";
        return value.substring(0,1).toUpperCase(RU) + value.substring(1);
    }
}
