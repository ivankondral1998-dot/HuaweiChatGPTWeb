package app.uno.pulse;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.SystemClock;
import android.view.View;

/** Lightweight, bitmap-free animated artwork; ~11 frames/sec when visible. */
public final class OrbitView extends View {
    private static final int CYAN = Color.rgb(109, 251, 233);
    private static final int VIOLET = Color.rgb(168, 147, 255);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF ring = new RectF();
    private Shader glow;
    private Shader beam;
    private int accent = CYAN;
    private boolean running;

    public OrbitView(Context context) {
        super(context);
        setContentDescription("Анимированное ядро UNO Pulse. Нажмите для смены цвета.");
        setClickable(true);
    }

    public void cyclePalette() {
        accent = accent == CYAN ? VIOLET : CYAN;
        rebuildShaders();
        invalidate();
    }

    public void setRunning(boolean running) {
        this.running = running;
        if (running) invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildShaders();
    }

    private void rebuildShaders() {
        float x = getWidth() / 2f;
        float y = getHeight() / 2f;
        float radius = Math.min(getWidth(), getHeight()) * .48f;
        if (radius <= 0) return;
        glow = new RadialGradient(x, y, radius,
                new int[]{withAlpha(accent, 55), withAlpha(accent, 11), 0x00000000},
                new float[]{0f, .55f, 1f}, Shader.TileMode.CLAMP);
        beam = new LinearGradient(x - radius, y - radius, x + radius, y + radius,
                new int[]{withAlpha(accent, 15), withAlpha(accent, 130), withAlpha(accent, 10)},
                null, Shader.TileMode.CLAMP);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth(), h = getHeight();
        float x = w / 2f, y = h / 2f;
        float r = Math.min(w * .43f, h * .44f);
        if (r <= 0) return;
        float seconds = SystemClock.uptimeMillis() / 1000f;

        reset();
        paint.setShader(glow);
        canvas.drawCircle(x, y, r * 1.12f, paint);
        paint.setShader(null);

        // Tiny deterministic satellites, no objects allocated per frame.
        for (int i = 0; i < 36; i++) {
            double a = (i * 137.508 + 19) * Math.PI / 180d;
            float distance = r * (.82f + (i % 5) * .13f);
            int alpha = 28 + (i % 4) * 24;
            paint.setColor(Color.argb(alpha, 186, 231, 249));
            paint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(x + (float) Math.cos(a) * distance,
                    y + (float) Math.sin(a) * distance, i % 7 == 0 ? 2.0f : .9f, paint);
        }

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.2f);
        paint.setColor(withAlpha(accent, 50));
        canvas.drawCircle(x, y, r * .93f, paint);
        paint.setColor(withAlpha(accent, 35));
        canvas.drawCircle(x, y, r * .66f, paint);
        paint.setColor(withAlpha(accent, 60));
        canvas.drawCircle(x, y, r * .36f, paint);

        // Orbit segments move in opposite directions.
        paint.setStrokeCap(Paint.Cap.ROUND);
        ring.set(x - r * .89f, y - r * .89f, x + r * .89f, y + r * .89f);
        paint.setColor(accent);
        paint.setStrokeWidth(3.2f);
        canvas.drawArc(ring, seconds * 13f, 87, false, paint);
        canvas.drawArc(ring, seconds * 13f + 180, 35, false, paint);
        ring.set(x - r * .77f, y - r * .77f, x + r * .77f, y + r * .77f);
        paint.setColor(0xC0909BFF);
        paint.setStrokeWidth(2f);
        canvas.drawArc(ring, 290 - seconds * 10f, 65, false, paint);
        canvas.drawArc(ring, 100 - seconds * 10f, 18, false, paint);

        paint.setShader(beam);
        paint.setStrokeWidth(1f);
        ring.set(x - r * .49f, y - r * .49f, x + r * .49f, y + r * .49f);
        canvas.drawOval(ring, paint);
        paint.setShader(null);

        // Stable center marks + a breathing core.
        float breath = 1f + (float) Math.sin(seconds * 1.2f) * .06f;
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xE6091727);
        canvas.drawCircle(x, y, r * .3f * breath, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(withAlpha(accent, 180));
        paint.setStrokeWidth(1.6f);
        canvas.drawCircle(x, y, r * .3f * breath, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 1));
        paint.setTextSize(r * .17f);
        canvas.drawText("PULSE", x, y - r * .015f, paint);
        paint.setColor(withAlpha(accent, 210));
        paint.setTextSize(r * .074f);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif", 0));
        canvas.drawText("ОФЛАЙН  ·  ТВОЙ МИР", x, y + r * .13f, paint);

        // Small crosshair ticks.
        paint.setColor(withAlpha(accent, 100));
        paint.setStrokeWidth(1.1f);
        for (int i = 0; i < 12; i++) {
            float a = (float)(i * Math.PI / 6);
            float in = r * .98f, out = r * 1.02f;
            canvas.drawLine(x + (float)Math.cos(a) * in, y + (float)Math.sin(a) * in,
                    x + (float)Math.cos(a) * out, y + (float)Math.sin(a) * out, paint);
        }

        if (running) postInvalidateDelayed(90);
    }

    private void reset() {
        paint.reset();
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.FILL);
    }
    private static int withAlpha(int color, int alpha) {
        return (color & 0x00ffffff) | (alpha << 24);
    }
}
