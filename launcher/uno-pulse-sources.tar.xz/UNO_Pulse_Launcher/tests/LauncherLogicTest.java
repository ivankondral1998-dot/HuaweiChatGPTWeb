import app.uno.pulse.LauncherLogic;
import java.util.Arrays;
import java.util.List;

public class LauncherLogicTest {
    public static void main(String[] args) {
        List<String> loaded = LauncherLogic.decodeFavorites("a|b|a||c");
        check(loaded.equals(Arrays.asList("a", "b", "c")), "dedup saved favorites");
        check(LauncherLogic.encodeFavorites(loaded).equals("a|b|c"), "encode saved favorites");
        check(LauncherLogic.matches("Камера", "com.test.camera", "КАМ"), "Cyrillic search");
        check(LauncherLogic.matches("Browser", "com.example.browser", "example"), "package search");
        check(!LauncherLogic.matches("Browser", "com.example.browser", "camera"), "exclude nonmatch");
        check(LauncherLogic.matches("Browser", "x", " "), "empty query");
        check(LauncherLogic.toggleFavorite(loaded, "d", 3) == null, "favorite limit");
        check(LauncherLogic.toggleFavorite(loaded, "a", 3).equals(Arrays.asList("b", "c")), "unpin");
        check(LauncherLogic.toggleFavorite(Arrays.asList("a"), "b", 3).equals(Arrays.asList("a", "b")), "pin");
        System.out.println("LauncherLogicTest: 9/9 PASS");
    }
    private static void check(boolean ok, String name) {
        if (!ok) throw new AssertionError(name);
    }
}
